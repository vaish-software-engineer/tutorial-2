
public class ICICI extends Bank {
	@Override
	public float getRateOfInterest() {
		return 6.9f;
	}
}
