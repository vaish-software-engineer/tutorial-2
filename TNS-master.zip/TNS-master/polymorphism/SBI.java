
public class SBI extends Bank {
	@Override
	public float getRateOfInterest() {
		return 7.0f;
	}
}
